module edu.miracostacollege.cs112.ic15_nobelpeaceprize {
  requires javafx.controls;
  requires javafx.fxml;


  exports edu.miracostacollege.cs112.ic15_nobelpeaceprize.view;
}