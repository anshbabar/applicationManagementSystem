package edu.miracostacollege.cs112.ic15_nobelpeaceprize.view;


import edu.miracostacollege.cs112.ic15_nobelpeaceprize.controller.Controller;
import edu.miracostacollege.cs112.ic15_nobelpeaceprize.model.NobelLaureate;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Color;

import java.util.Collections;
public class MainScene extends Scene {
    public static final int WIDTH = 700;
    public static final int HEIGHT = 700;

    private ImageView employeeIV = new ImageView();
    //private ComboBox<String> laureateTypeCB = new ComboBox<>();
    private TextField nameTF = new TextField();
    private Label nameLabel = new Label("Name:");
    private Label nameErrLabel = new Label("Name is required.");

    private TextField contactInfoTF = new TextField();
    private Label contactInfoErrLabel = new Label("Contact information is required.");

    private TextField ageTF = new TextField();
    private Label ageErrLabel = new Label("Age is required.");

    private TextField hoursTF = new TextField();
    private Label hoursErrLabel = new Label("Date of birth is required.");

    private TextField reasonForApplyingTF = new TextField();
    private Label reasonForApplyingErrLabel = new Label("Explanation required.");

    private ListView<NobelLaureate> employeesLV = new ListView<>();

    private Button removeButton = new Button("- Remove Application");
    private Button addButton = new Button("+ Add Application");

    private Controller controller = Controller.getInstance();
    private ObservableList<NobelLaureate> employeesList;
    private NobelLaureate selectedLaureate;


    public MainScene() {
        super(new GridPane(), WIDTH, HEIGHT);

        GridPane pane = new GridPane();
        pane.setHgap(10.0);
        pane.setVgap(5);
        pane.setPadding(new Insets(5));



        employeeIV.setImage(new Image("resized.png"));
        employeeIV.setFitWidth(WIDTH);
        pane.add(employeeIV, 0, 0, 3, 1);

        pane.add(nameLabel, 0, 2);
        pane.add(nameTF, 1, 2);
        pane.add(nameErrLabel, 2, 2);
        nameErrLabel.setTextFill(Color.RED);
        nameErrLabel.setVisible(false);

        pane.add(new Label("Age:"), 0, 3);
        pane.add(ageTF, 1, 3);
        pane.add(ageErrLabel, 2, 3);
        ageErrLabel.setTextFill(Color.RED);
        ageErrLabel.setVisible(false);

        pane.add(new Label("Reason for applying:"), 0, 4);
        pane.add(reasonForApplyingTF, 1, 4);
        pane.add(reasonForApplyingErrLabel, 2, 4);
        reasonForApplyingErrLabel.setTextFill(Color.RED);
        reasonForApplyingErrLabel.setVisible(false);

        pane.add(new Label("Contact info:"), 0, 5);
        pane.add(contactInfoTF, 1, 5);
        pane.add(contactInfoErrLabel, 2, 5);
        contactInfoErrLabel.setTextFill(Color.RED);
        contactInfoErrLabel.setVisible(false);


        pane.add(new Label("Hours available (week):"), 0, 6);
        pane.add(hoursTF, 1, 6);
        pane.add(hoursErrLabel, 2, 6);
        hoursErrLabel.setTextFill(Color.RED);
        hoursErrLabel.setVisible(false);


        pane.add(addButton, 1, 7);
        addButton.setOnAction(e -> addLaureate());
        employeesLV.setPrefWidth(WIDTH);
        pane.add(employeesLV, 0, 8, 3, 1);
        pane.add(removeButton, 0, 9);

        removeButton.setOnAction(e -> removeLaureate());
        employeesList = controller.getAllLaureates();
        employeesLV.setItems(employeesList);
        employeesLV.getSelectionModel().selectedItemProperty().addListener((obsVal, oldVal, newVal) -> removeMethod(newVal));

        removeButton.setDisable(true);

        this.setRoot(pane);
    }

    private void removeMethod(NobelLaureate newVal) {
        selectedLaureate = newVal;
        removeButton.setDisable(selectedLaureate == null);
    }
/*

    private void switcharoo(int intValue) {
        if (intValue == 0){
            nameLabel.setText("Individual's Name");
        }
        else
        {
            nameLabel.setText("Organization's Name");
        }
    }
*/
    

    private void removeLaureate() {

        if (selectedLaureate != null){
            employeesList.remove(selectedLaureate);

        }
    }


    private void addLaureate() {
        String name = nameTF.getText();
        nameErrLabel.setVisible(name.isEmpty());
        int age = 0;
        try {
            age = Integer.parseInt(ageTF.getText());
            ageErrLabel.setVisible(age < 0);
        } catch (NumberFormatException e) {
            ageErrLabel.setVisible(true);
        }

        String reasonForApplying = reasonForApplyingTF.getText();
        reasonForApplyingErrLabel.setVisible(reasonForApplying.isEmpty());

        String contactInfo = contactInfoTF.getText();
        contactInfoErrLabel.setVisible(contactInfo.isEmpty());

        double hours = 0;
        try {
            hours = Double.parseDouble(hoursTF.getText());
            hoursErrLabel.setVisible(hours < 0);
        } catch (NumberFormatException e){
            hoursErrLabel.setVisible(true);
        }
        if(nameErrLabel.isVisible() || ageErrLabel.isVisible() || reasonForApplyingErrLabel.isVisible() || contactInfoErrLabel.isVisible() || hoursErrLabel.isVisible())
            return;
        employeesList.add(0, new NobelLaureate(name, age, reasonForApplying, contactInfo, hours));
        Collections.sort(employeesList);
        }


    private void updateDisplay()
    {
        employeesLV.refresh();
    }

}
