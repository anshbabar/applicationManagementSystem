package edu.miracostacollege.cs112.ic15_nobelpeaceprize.controller;

import edu.miracostacollege.cs112.ic15_nobelpeaceprize.model.Model;
import edu.miracostacollege.cs112.ic15_nobelpeaceprize.model.NobelLaureate;
import javafx.collections.ObservableList;

import java.util.Collections;

public class Controller {

	private static Controller theInstance;
	private ObservableList<NobelLaureate> mAllLaureatesList;
	// Make private constructor
	private Controller(){

	}

	public static Controller getInstance() {
		if (theInstance == null)
		{
			theInstance = new Controller();
			if (Model.binaryFileHasData())
			{
				theInstance.mAllLaureatesList = Model.populateListFromBinaryFile();
			}
			else
			{
				theInstance.mAllLaureatesList = Model.populateListFromCSVFile();
				Collections.sort(theInstance.mAllLaureatesList);
			}
		}
		return theInstance;
	}

	public ObservableList<NobelLaureate> getAllLaureates()
	{
		return mAllLaureatesList;
	}

	public void saveData() {
		Model.writeDataToBinaryFile(mAllLaureatesList);
	}
}
