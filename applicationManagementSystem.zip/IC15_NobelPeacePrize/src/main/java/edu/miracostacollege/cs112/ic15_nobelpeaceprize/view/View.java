package edu.miracostacollege.cs112.ic15_nobelpeaceprize.view;

import edu.miracostacollege.cs112.ic15_nobelpeaceprize.controller.Controller;
import javafx.application.Application;
import javafx.scene.image.Image;
import javafx.stage.Stage;


public class View extends Application {

	@Override
	public void start(Stage primaryStage) throws Exception {
		ViewNavigator.setStage(primaryStage);
		//DONE: Uncomment when res folder has been configured:
		primaryStage.getIcons().add(new Image("download.png"));
		ViewNavigator.loadScene("Employee Application", new MainScene());
	}

	@Override
	public void stop() throws Exception {
		// DONE: Uncomment when finished with Controller.java
		 Controller.getInstance().saveData();
	}

	public static void main(String[] args) {
		Application.launch(args);

	}

}
