package edu.miracostacollege.cs112.ic15_nobelpeaceprize.model;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.io.*;
import java.nio.file.FileSystems;
import java.util.Arrays;
import java.util.Scanner;


public class Model {
	
	public static final String BINARY_FILE = "Laureates.dat";
	public static final String CSV_FILE = "NobelPeacePrizeWinners.csv";

	public static boolean binaryFileHasData()
	{
		File binaryFile = new File(BINARY_FILE);
		return binaryFile.exists() && binaryFile.length() > 5;
	}
	public static ObservableList<NobelLaureate> populateListFromCSVFile()
	{
		ObservableList<NobelLaureate> allLaureate = FXCollections.observableArrayList();
		// Open CSV File, read one line at a time, spilt into parts whenever commas appear
		try {
			Scanner fileReader = new Scanner(new File(CSV_FILE));
			int year;
			double prizeAmount;
			String name, motivation, country, line;
			String[] parts;
			// Skip the header
			fileReader.nextLine();
			while (fileReader.hasNextLine())
			{
				line = fileReader.nextLine();
				parts = line.split(","); // 0, 6, 9, 13, 26
				year = Integer.parseInt(parts[0]);
				prizeAmount = Double.parseDouble(parts[6]);
				motivation = parts[9];
				name = parts[13];
				country = parts[26];
				allLaureate.add(new NobelLaureate(name, year, motivation, country, prizeAmount));
			}
			// If done reading, close file.
			fileReader.close();
		} catch (FileNotFoundException e) {
			System.err.println("Error: " + e.getMessage());
		}
		return allLaureate;
	}

	public static ObservableList<NobelLaureate> populateListFromBinaryFile()
	{
		ObservableList<NobelLaureate> allLaureates = FXCollections.observableArrayList();

		try {
			ObjectInputStream fileReader = new ObjectInputStream(new FileInputStream(BINARY_FILE));
			// Read data into array
			NobelLaureate[] tempArray = (NobelLaureate[]) fileReader.readObject();
			// Loop through array and each object to the list
			for (int i = 0; i < tempArray.length; i++) {
				allLaureates.add(tempArray[i]);
			}
			fileReader.close();
		} catch (IOException | ClassNotFoundException e) {
			System.err.println("Error " + e.getMessage());
		}
		return allLaureates;
	}

	public static boolean writeDataToBinaryFile(ObservableList<NobelLaureate> allLaureatesList)
	{
		try {
			ObjectOutputStream fileWriter = new ObjectOutputStream(new FileOutputStream(BINARY_FILE));
			NobelLaureate[] tempArray = new NobelLaureate[allLaureatesList.size()];
			allLaureatesList.toArray(tempArray);
			// Write TempArray to binary file
			fileWriter.writeObject(tempArray);
			fileWriter.close();
			return true;
		} catch (IOException e) {
			System.err.println("Error " + e.getMessage());
			return false;
		}

	}

}
