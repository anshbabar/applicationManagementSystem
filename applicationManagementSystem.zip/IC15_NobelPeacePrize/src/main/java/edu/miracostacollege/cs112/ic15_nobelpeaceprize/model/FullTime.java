package edu.miracostacollege.cs112.ic15_nobelpeaceprize.model;

import java.util.Objects;

public class FullTime extends NobelLaureate{
    private boolean benefits;

    public FullTime(String name, int awardYear, String motivation, String birthCountry, double prizeAmount, boolean benefits) {
        super(name, awardYear, motivation, birthCountry, prizeAmount);
        this.benefits = benefits;
    }

    public boolean isBenefits() {
        return benefits;
    }

    public void setBenefits(boolean benefits) {
        this.benefits = benefits;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        if (!super.equals(o)) return false;
        FullTime fullTime = (FullTime) o;
        return benefits == fullTime.benefits;
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), benefits);
    }

    @Override
    public String toString() {
        return "FullTime{" +
                "benefits=" + benefits +
                '}';
    }
}
